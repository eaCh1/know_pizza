package com.example.android.knowpizza;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void feedMePizza(View view) {
        //Collect responses, Check the Answers while creating Message, then Toast it

        //Question 1
        RadioGroup answerOneGroup = (RadioGroup) findViewById(R.id.AQ1);
        int AnswerOne = answerOneGroup.getCheckedRadioButtonId();

        //Question 2
        EditText answerTwoGroup = (EditText) findViewById(R.id.AQ2);
        String AnswerTwo = answerTwoGroup.getText().toString();

        //Question 3
        CheckBox answerThreeGroup1 = (CheckBox) findViewById(R.id.AQ3_1);
        boolean AnswerThree1 = answerThreeGroup1.isChecked();

        CheckBox answerThreeGroup2 = (CheckBox) findViewById(R.id.AQ3_2);
        boolean AnswerThree2 = answerThreeGroup2.isChecked();

        CheckBox answerThreeGroup3 = (CheckBox) findViewById(R.id.AQ3_3);
        boolean AnswerThree3 = answerThreeGroup3.isChecked();

        CheckBox answerThreeGroup4 = (CheckBox) findViewById(R.id.AQ3_4);
        boolean AnswerThree4 = answerThreeGroup4.isChecked();

        //Question 4
        RadioGroup answerFourGroup = (RadioGroup) findViewById(R.id.AQ4);
        int AnswerFour = answerFourGroup.getCheckedRadioButtonId();

        //Question 5
        RadioGroup answerFiveGroup = (RadioGroup) findViewById(R.id.AQ5);
        int AnswerFive = answerFiveGroup.getCheckedRadioButtonId();


        //Check Answers, create Message
        String scoreMessage = checkAnswers(
                AnswerOne,
                AnswerTwo,
                AnswerThree1,
                AnswerThree2,
                AnswerThree3,
                AnswerThree4,
                AnswerFour,
                AnswerFive);

        //Toast it!
        Toast toast = Toast.makeText(this, scoreMessage, Toast.LENGTH_SHORT);
        toast.show();

    }

    //Compares all the user's answers to the grading rubric, returns string ScoreMessage
    private String checkAnswers(int AnswerOne,
                                String AnswerTwo,
                                boolean AnswerThree1,
                                boolean AnswerThree2,
                                boolean AnswerThree3,
                                boolean AnswerThree4,
                                int AnswerFour,
                                int AnswerFive) {

        String scoreMessage = "";
        int score = 0;

        //Question 1
        if (AnswerOne == 1) {
            scoreMessage += "Your response to Question 1 is correct!";
            score += 1;
        } else {
            scoreMessage += "Your response to Question 1 is incorrect.";
        }

        //Question 2
        if (AnswerTwo.equals("efficient")) {
            scoreMessage += "\nYour response to Question 2 is correct!";
            score += 1;
        } else {
            scoreMessage += "\nYour response to Question 2 is incorrect.";
        }

        //Question 3
        if (AnswerThree1 && AnswerThree3 && !AnswerThree2 && !AnswerThree4) {
            scoreMessage += "\nYour response to Question 3 is correct!";
            score += 1;
        } else {
            scoreMessage += "\nYour response to Question 3 is incorrect.";
        }

        //Question 4
        if (AnswerFour == 4) {
            scoreMessage += "\nYour response to Question 4 is correct!";
            score += 1;
        } else {
            scoreMessage += "\nYour response to Question 4 is incorrect.";
        }

        //Question 5
        if (AnswerFive == 8) {
            scoreMessage += "\nYour response to Question 5 is correct!";
            score += 1;
        } else {
            scoreMessage += "\nYour response to Question 5 is incorrect.";
        }


        scoreMessage += "\n\nYour total score is " + score;
        return scoreMessage;

    }

}




